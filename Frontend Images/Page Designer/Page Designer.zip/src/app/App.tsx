import React, { useState } from "react";
import {
  Type, Film, LayoutGrid, Minus,
  ChevronUp, ChevronDown, Trash2, Plus, Copy,
  Monitor, Tablet, Smartphone, Eye, Save,
  X, ChevronLeft, ChevronRight,
  AlignLeft, AlignCenter, AlignRight,
  Hash, Star, Zap, Check,
  Upload, Layers, Settings, RotateCcw, RotateCw,
  Image as ImageIcon,
} from "lucide-react";
import hathorLogo from "@/imports/Logo_Colors___White_Small.svg";

// ── Design tokens ──────────────────────────────────────────────────────────────
const BG = "#222831";
const SURFACE = "#1C2028";
const BORDER = "#393E46";
const ORANGE = "#FD7014";
const TEXT = "#EEEEEE";
const MUTED = "#8C9AAA";

// ── Font & weight options for the designer ─────────────────────────────────────
const FONTS = [
  { label: "Cinzel", value: "'Cinzel', serif" },
  { label: "Cinzel Decorative", value: "'Cinzel Decorative', serif" },
  { label: "Raleway", value: "'Raleway', sans-serif" },
  { label: "Inter", value: "'Inter', sans-serif" },
  { label: "Playfair Display", value: "'Playfair Display', serif" },
  { label: "Space Grotesk", value: "'Space Grotesk', sans-serif" },
  { label: "Oswald", value: "'Oswald', sans-serif" },
  { label: "Lora", value: "'Lora', serif" },
];

const WEIGHTS = [
  { label: "Thin (100)", value: "100" },
  { label: "Light (300)", value: "300" },
  { label: "Regular (400)", value: "400" },
  { label: "Medium (500)", value: "500" },
  { label: "SemiBold (600)", value: "600" },
  { label: "Bold (700)", value: "700" },
  { label: "ExtraBold (800)", value: "800" },
  { label: "Black (900)", value: "900" },
];

// ── Types ─────────────────────────────────────────────────────────────────────
type SectionType = "hero" | "text" | "image" | "carousel" | "features" | "two-col" | "divider" | "spacer" | "cta";
type Device = "desktop" | "tablet" | "mobile";
type LucideIcon = React.ComponentType<{ size?: number; className?: string; style?: React.CSSProperties }>;

interface FeatureItem { icon: string; title: string; desc: string; color: string; }

interface Section {
  id: string; type: SectionType;
  bg: string; bgImage: string; overlay: number;
  pt: number; pb: number; ph: number; radius: number;
  // Hero
  heroTitle?: string; heroSubtitle?: string; heroCtaText?: string;
  heroCtaBg?: string; heroCtaColor?: string; heroTitleFont?: string;
  heroTitleSize?: number; heroTitleWeight?: string; heroTitleColor?: string;
  heroSubtitleColor?: string; heroAlign?: string;
  // Text
  textContent?: string; textFont?: string; textSize?: number;
  textWeight?: string; textColor?: string; textAlign?: string;
  textLineHeight?: number; textMaxWidth?: number;
  // Image
  imageSrc?: string; imageAlt?: string; imageRadius?: number;
  imageMaxWidth?: number; imageShadow?: boolean;
  // Carousel
  carouselImages?: string[]; carouselHeight?: number; carouselRadius?: number;
  // Features
  featuresTitle?: string; featuresTitleFont?: string; featuresTitleColor?: string;
  featuresCols?: number; featuresItems?: FeatureItem[];
  // Two-col
  twoColRatio?: string; twoColGap?: number;
  twoColLeftType?: "text" | "image"; twoColLeftText?: string; twoColLeftFont?: string;
  twoColLeftSize?: number; twoColLeftWeight?: string; twoColLeftColor?: string;
  twoColLeftAlign?: string; twoColLeftImg?: string;
  twoColRightType?: "text" | "image"; twoColRightText?: string; twoColRightFont?: string;
  twoColRightSize?: number; twoColRightWeight?: string; twoColRightColor?: string;
  twoColRightAlign?: string; twoColRightImg?: string;
  // Divider
  dividerColor?: string; dividerStyle?: string; dividerThickness?: number; dividerWidth?: number;
  // Spacer
  spacerHeight?: number;
  // CTA
  ctaTitle?: string; ctaSubtitle?: string; ctaPrice?: string; ctaBtnText?: string;
  ctaBtnColor?: string; ctaBtnTextColor?: string; ctaTitleFont?: string;
  ctaTitleColor?: string; ctaSubtitleColor?: string; ctaAlign?: string;
}

// ── Helpers ───────────────────────────────────────────────────────────────────
function uid() { return Math.random().toString(36).slice(2, 8); }

function createSection(type: SectionType): Section {
  const base = { id: uid(), bg: "#111118", bgImage: "", overlay: 0, pt: 60, pb: 60, ph: 48, radius: 0 };
  switch (type) {
    case "hero": return {
      ...base, type, bg: "#0d0d14", bgImage: `https://picsum.photos/seed/${uid()}/1400/700`,
      overlay: 55, pt: 130, pb: 130,
      heroTitle: "Your Game Title", heroSubtitle: "Your epic tagline goes here.",
      heroCtaText: "Add to Cart — $29.99", heroCtaBg: "#FD7014", heroCtaColor: "#ffffff",
      heroTitleFont: "'Cinzel', serif", heroTitleSize: 56, heroTitleWeight: "900",
      heroTitleColor: "#ffffff", heroSubtitleColor: "#cccccc", heroAlign: "center",
    };
    case "text": return {
      ...base, type,
      textContent: "Add your description here. Tell players about your game's story, gameplay, or features.",
      textFont: "'Raleway', sans-serif", textSize: 16, textWeight: "400",
      textColor: "#CCCCCC", textAlign: "center", textLineHeight: 1.8, textMaxWidth: 680,
    };
    case "image": return {
      ...base, type,
      imageSrc: `https://picsum.photos/seed/${uid()}/900/500`, imageAlt: "Game screenshot",
      imageRadius: 0, imageMaxWidth: 100, imageShadow: false,
    };
    case "carousel": return {
      ...base, type, pt: 0, pb: 0, ph: 0,
      carouselImages: [
        `https://picsum.photos/seed/${uid()}/900/450`,
        `https://picsum.photos/seed/${uid()}/900/450`,
        `https://picsum.photos/seed/${uid()}/900/450`,
      ],
      carouselHeight: 420, carouselRadius: 0,
    };
    case "features": return {
      ...base, type,
      featuresTitle: "Key Features", featuresTitleFont: "'Cinzel', serif",
      featuresTitleColor: "#ffffff", featuresCols: 3,
      featuresItems: [
        { icon: "🎮", title: "Feature One", desc: "Describe your first key feature here.", color: "#FD7014" },
        { icon: "⚡", title: "Feature Two", desc: "Describe your second key feature here.", color: "#4caf80" },
        { icon: "🌟", title: "Feature Three", desc: "Describe your third key feature here.", color: "#3b9eda" },
      ],
    };
    case "two-col": return {
      ...base, type, twoColRatio: "1:1", twoColGap: 48,
      twoColLeftType: "text",
      twoColLeftText: "Add your left column text here.\n\nYou can include system requirements, lore, or feature details.",
      twoColLeftFont: "'Raleway', sans-serif", twoColLeftSize: 14,
      twoColLeftWeight: "400", twoColLeftColor: "#CCCCCC", twoColLeftAlign: "left",
      twoColRightType: "image", twoColRightImg: `https://picsum.photos/seed/${uid()}/600/400`,
    };
    case "divider": return {
      ...base, type, pt: 16, pb: 16,
      dividerColor: "#393E46", dividerStyle: "solid", dividerThickness: 1, dividerWidth: 80,
    };
    case "spacer": return { ...base, type, pt: 0, pb: 0, bg: "transparent", spacerHeight: 60 };
    case "cta": return {
      ...base, type, bg: "#0d0d14", pt: 100, pb: 100,
      ctaTitle: "Get the Game", ctaSubtitle: "Available on Windows, macOS and Linux.",
      ctaPrice: "$29.99", ctaBtnText: "Add to Cart",
      ctaBtnColor: "#FD7014", ctaBtnTextColor: "#ffffff",
      ctaTitleFont: "'Cinzel', serif", ctaTitleColor: "#ffffff",
      ctaSubtitleColor: "#AAAAAA", ctaAlign: "center",
    };
    default: return { ...base, type };
  }
}

// ── Preset initial page ────────────────────────────────────────────────────────
const INITIAL: Section[] = [
  {
    id: "s1", type: "hero",
    bg: "#0a0a12", bgImage: "https://picsum.photos/seed/darkfantasy77/1400/700",
    overlay: 55, pt: 140, pb: 140, ph: 48, radius: 0,
    heroTitle: "ELDEN THRONE", heroSubtitle: "Forge your legend across a shattered world of gods and ruin.",
    heroCtaText: "Add to Cart — $59.99", heroCtaBg: "#FD7014", heroCtaColor: "#ffffff",
    heroTitleFont: "'Cinzel', serif", heroTitleSize: 60, heroTitleWeight: "900",
    heroTitleColor: "#ffffff", heroSubtitleColor: "#cccccc", heroAlign: "center",
  },
  {
    id: "s2", type: "text",
    bg: "#0f0f18", bgImage: "", overlay: 0, pt: 72, pb: 72, ph: 48, radius: 0,
    textContent: "In a world broken by the fall of the First Gods, you rise as an Elden-seeker — a warrior unbound by fate. Traverse vast dungeons, battle ancient colossi, and forge alliances with forgotten civilizations across 60+ interconnected zones.",
    textFont: "'Raleway', sans-serif", textSize: 17, textWeight: "400",
    textColor: "#BBBBBB", textAlign: "center", textLineHeight: 1.85, textMaxWidth: 700,
  },
  {
    id: "s3", type: "carousel",
    bg: "#080810", bgImage: "", overlay: 0, pt: 0, pb: 0, ph: 0, radius: 0,
    carouselImages: [
      "https://picsum.photos/seed/screen-a1/1000/500",
      "https://picsum.photos/seed/screen-b2/1000/500",
      "https://picsum.photos/seed/screen-c3/1000/500",
      "https://picsum.photos/seed/screen-d4/1000/500",
    ],
    carouselHeight: 460, carouselRadius: 0,
  },
  {
    id: "s4", type: "features",
    bg: "#0f0f18", bgImage: "", overlay: 0, pt: 88, pb: 88, ph: 48, radius: 0,
    featuresTitle: "Core Features", featuresTitleFont: "'Cinzel', serif",
    featuresTitleColor: "#ffffff", featuresCols: 3,
    featuresItems: [
      { icon: "⚔️", title: "Epic Combat", desc: "Master 200+ unique weapons across 8 battle disciplines. Every fight is a test of skill.", color: "#FD7014" },
      { icon: "🌍", title: "Vast Open World", desc: "Explore 60+ zones spanning deserts, tundra, and underwater caverns.", color: "#4caf80" },
      { icon: "🧙", title: "Deep Progression", desc: "Build your legend through 500+ skill nodes and legendary equipment sets.", color: "#3b9eda" },
    ],
  },
  {
    id: "s5", type: "two-col",
    bg: "#080810", bgImage: "", overlay: 0, pt: 88, pb: 88, ph: 48, radius: 0,
    twoColRatio: "1:1", twoColGap: 56,
    twoColLeftType: "text",
    twoColLeftText: "System Requirements\n\nMinimum:\nOS: Windows 10 64-bit\nCPU: Intel Core i5-8400\nRAM: 12 GB\nGPU: NVIDIA GTX 1060 6GB\nStorage: 80 GB SSD\n\nRecommended:\nOS: Windows 11 64-bit\nCPU: Intel Core i7-10700K\nRAM: 16 GB\nGPU: NVIDIA RTX 3070\nStorage: 80 GB NVMe SSD",
    twoColLeftFont: "'Space Grotesk', sans-serif", twoColLeftSize: 13,
    twoColLeftWeight: "400", twoColLeftColor: "#AAAAAA", twoColLeftAlign: "left",
    twoColRightType: "image", twoColRightImg: "https://picsum.photos/seed/game-art9/600/500",
  },
  {
    id: "s6", type: "cta",
    bg: "#0a0a12", bgImage: "https://picsum.photos/seed/cta-dark5/1400/500",
    overlay: 78, pt: 100, pb: 100, ph: 48, radius: 0,
    ctaTitle: "Begin Your Legend",
    ctaSubtitle: "Available now on Windows, macOS and Linux.",
    ctaPrice: "$59.99", ctaBtnText: "Add to Cart",
    ctaBtnColor: "#FD7014", ctaBtnTextColor: "#ffffff",
    ctaTitleFont: "'Cinzel', serif", ctaTitleColor: "#ffffff",
    ctaSubtitleColor: "#AAAAAA", ctaAlign: "center",
  },
];

// ── Palette config ────────────────────────────────────────────────────────────
const PALETTE: { group: string; items: { type: SectionType; label: string; desc: string; Icon: LucideIcon }[] }[] = [
  {
    group: "Sections",
    items: [
      { type: "hero", label: "Hero Banner", desc: "Title, subtitle & CTA", Icon: Star },
      { type: "cta", label: "CTA Block", desc: "Price & buy button", Icon: Zap },
    ],
  },
  {
    group: "Content",
    items: [
      { type: "text", label: "Text", desc: "Paragraph or heading", Icon: Type },
      { type: "image", label: "Image", desc: "Single image block", Icon: ImageIcon },
      { type: "carousel", label: "Carousel", desc: "Image slideshow", Icon: Film },
      { type: "features", label: "Features Grid", desc: "Icon cards", Icon: LayoutGrid },
      { type: "two-col", label: "Two Columns", desc: "Side-by-side layout", Icon: Layers },
    ],
  },
  {
    group: "Extras",
    items: [
      { type: "divider", label: "Divider", desc: "Horizontal rule", Icon: Minus },
      { type: "spacer", label: "Spacer", desc: "Vertical space", Icon: Hash },
    ],
  },
];

const BLOCK_META: Record<SectionType, { label: string; Icon: LucideIcon }> = {
  hero: { label: "Hero Banner", Icon: Star },
  text: { label: "Text Block", Icon: Type },
  image: { label: "Image", Icon: ImageIcon },
  carousel: { label: "Carousel", Icon: Film },
  features: { label: "Features Grid", Icon: LayoutGrid },
  "two-col": { label: "Two Columns", Icon: Layers },
  divider: { label: "Divider", Icon: Minus },
  spacer: { label: "Spacer", Icon: Hash },
  cta: { label: "CTA Block", Icon: Zap },
};

// ── Property control helpers ───────────────────────────────────────────────────
function PropSection({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="border-b" style={{ borderColor: BORDER }}>
      <p className="px-4 pt-3 pb-1.5 text-[7px] font-mono tracking-[0.3em] uppercase" style={{ color: `${MUTED}90` }}>{title}</p>
      <div className="px-4 pb-4 space-y-2.5">{children}</div>
    </div>
  );
}
function PropRow({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1">
      <p className="text-[8px] font-mono" style={{ color: MUTED }}>{label}</p>
      {children}
    </div>
  );
}
function ColorField({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  return (
    <div className="flex items-center gap-2 border px-2 py-1.5" style={{ borderColor: BORDER, background: BG }}>
      <div className="w-5 h-5 shrink-0 border" style={{ background: value, borderColor: `${BORDER}80` }} />
      <input type="text" value={value} onChange={e => onChange(e.target.value)}
        className="flex-1 bg-transparent text-[9px] font-mono outline-none" style={{ color: TEXT }}
        placeholder="#000000" />
    </div>
  );
}
function NumField({ value, onChange, min = 0, max = 9999, step = 1, unit }: {
  value: number; onChange: (v: number) => void; min?: number; max?: number; step?: number; unit?: string;
}) {
  return (
    <div className="flex items-center border" style={{ borderColor: BORDER, background: BG }}>
      <button onClick={() => onChange(Math.max(min, +(value - step).toFixed(2)))}
        className="px-2 py-1.5 border-r text-muted-foreground hover:text-foreground transition-colors text-[11px]"
        style={{ borderColor: BORDER }}>−</button>
      <input type="number" value={value} onChange={e => onChange(Number(e.target.value))}
        className="flex-1 bg-transparent text-center text-[9px] font-mono outline-none py-1.5"
        style={{ minWidth: 0, color: TEXT }} min={min} max={max} step={step} />
      {unit && <span className="text-[7px] font-mono px-1" style={{ color: MUTED }}>{unit}</span>}
      <button onClick={() => onChange(Math.min(max, +(value + step).toFixed(2)))}
        className="px-2 py-1.5 border-l text-muted-foreground hover:text-foreground transition-colors text-[11px]"
        style={{ borderColor: BORDER }}>+</button>
    </div>
  );
}
function TxtInput({ value, onChange, placeholder }: { value: string; onChange: (v: string) => void; placeholder?: string }) {
  return (
    <div className="border" style={{ borderColor: BORDER, background: BG }}>
      <input type="text" value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder}
        className="w-full bg-transparent px-2.5 py-2 text-[9px] font-mono outline-none placeholder-[#444]"
        style={{ color: TEXT }} />
    </div>
  );
}
function TxtArea({ value, onChange, rows = 4 }: { value: string; onChange: (v: string) => void; rows?: number }) {
  return (
    <div className="border" style={{ borderColor: BORDER, background: BG }}>
      <textarea value={value} onChange={e => onChange(e.target.value)} rows={rows}
        className="w-full bg-transparent px-2.5 py-2 text-[9px] font-mono outline-none resize-none"
        style={{ color: TEXT }} />
    </div>
  );
}
function SelField({ value, onChange, options }: {
  value: string; onChange: (v: string) => void; options: { label: string; value: string }[];
}) {
  return (
    <div className="border" style={{ borderColor: BORDER, background: BG }}>
      <select value={value} onChange={e => onChange(e.target.value)}
        className="w-full bg-transparent px-2.5 py-2 text-[9px] font-mono outline-none cursor-pointer"
        style={{ color: TEXT }}>
        {options.map(o => <option key={o.value} value={o.value} style={{ background: SURFACE, color: TEXT }}>{o.label}</option>)}
      </select>
    </div>
  );
}
function AlignField({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  return (
    <div className="flex border" style={{ borderColor: BORDER }}>
      {(["left", "center", "right"] as const).map(a => {
        const Icon = a === "left" ? AlignLeft : a === "center" ? AlignCenter : AlignRight;
        return (
          <button key={a} onClick={() => onChange(a)}
            className="flex-1 flex items-center justify-center py-1.5 transition-colors"
            style={{ background: value === a ? `${ORANGE}20` : "transparent", color: value === a ? ORANGE : MUTED, borderRight: a !== "right" ? `1px solid ${BORDER}` : undefined }}>
            <Icon size={11} />
          </button>
        );
      })}
    </div>
  );
}
function SliderField({ value, onChange, label }: { value: number; onChange: (v: number) => void; label: string }) {
  return (
    <div className="space-y-1">
      <div className="flex justify-between">
        <span className="text-[8px] font-mono" style={{ color: MUTED }}>{label}</span>
        <span className="text-[8px] font-mono" style={{ color: ORANGE }}>{value}%</span>
      </div>
      <input type="range" min={0} max={100} value={value} onChange={e => onChange(Number(e.target.value))}
        className="w-full" style={{ accentColor: ORANGE }} />
    </div>
  );
}

// ── Section renderers (live canvas preview) ────────────────────────────────────
function HeroRenderer({ s }: { s: Section }) {
  return (
    <div style={{ textAlign: (s.heroAlign || "center") as React.CSSProperties["textAlign"], maxWidth: 860, margin: "0 auto" }}>
      <h1 style={{ fontFamily: s.heroTitleFont, fontSize: s.heroTitleSize, fontWeight: s.heroTitleWeight as React.CSSProperties["fontWeight"],
        color: s.heroTitleColor, marginBottom: 20, lineHeight: 1.08, letterSpacing: "0.04em", textTransform: "uppercase" }}>
        {s.heroTitle || "Hero Title"}
      </h1>
      <p style={{ color: s.heroSubtitleColor, fontSize: 18, marginBottom: 36, lineHeight: 1.65, maxWidth: 560, margin: "0 auto 36px" }}>
        {s.heroSubtitle || "Your subtitle here"}
      </p>
      <button style={{ background: s.heroCtaBg, color: s.heroCtaColor, padding: "14px 40px",
        fontSize: 13, fontWeight: 700, letterSpacing: "0.12em", textTransform: "uppercase", border: "none", cursor: "pointer" }}>
        {s.heroCtaText || "Add to Cart"}
      </button>
    </div>
  );
}
function TextRenderer({ s }: { s: Section }) {
  return (
    <div style={{ maxWidth: s.textMaxWidth || 700, margin: "0 auto" }}>
      <p style={{ fontFamily: s.textFont, fontSize: s.textSize, fontWeight: s.textWeight as React.CSSProperties["fontWeight"],
        color: s.textColor, textAlign: (s.textAlign || "left") as React.CSSProperties["textAlign"],
        lineHeight: s.textLineHeight, whiteSpace: "pre-wrap" }}>
        {s.textContent || "Your text content"}
      </p>
    </div>
  );
}
function ImageRenderer({ s }: { s: Section }) {
  return (
    <div style={{ textAlign: "center" }}>
      <img src={s.imageSrc || "https://picsum.photos/900/500"} alt={s.imageAlt || ""}
        style={{ maxWidth: `${s.imageMaxWidth ?? 100}%`, width: "100%", display: "inline-block",
          borderRadius: s.imageRadius, boxShadow: s.imageShadow ? "0 24px 60px rgba(0,0,0,0.55)" : "none" }} />
    </div>
  );
}
function CarouselRenderer({ s }: { s: Section }) {
  const [idx, setIdx] = useState(0);
  const imgs = s.carouselImages || [];
  return (
    <div style={{ position: "relative", height: s.carouselHeight || 420, overflow: "hidden", borderRadius: s.carouselRadius, background: "#0a0a0f" }}>
      {imgs.length > 0 ? (
        <>
          <img src={imgs[idx]} alt="" style={{ width: "100%", height: "100%", objectFit: "cover", transition: "opacity 0.3s" }} />
          {imgs.length > 1 && (
            <>
              <button onClick={e => { e.stopPropagation(); setIdx(i => (i - 1 + imgs.length) % imgs.length); }}
                style={{ position: "absolute", left: 16, top: "50%", transform: "translateY(-50%)", background: "rgba(0,0,0,0.7)", border: "none", color: "#fff", padding: "10px 14px", cursor: "pointer", display: "flex", alignItems: "center" }}>
                <ChevronLeft size={20} />
              </button>
              <button onClick={e => { e.stopPropagation(); setIdx(i => (i + 1) % imgs.length); }}
                style={{ position: "absolute", right: 16, top: "50%", transform: "translateY(-50%)", background: "rgba(0,0,0,0.7)", border: "none", color: "#fff", padding: "10px 14px", cursor: "pointer", display: "flex", alignItems: "center" }}>
                <ChevronRight size={20} />
              </button>
              <div style={{ position: "absolute", bottom: 14, left: "50%", transform: "translateX(-50%)", display: "flex", gap: 6 }}>
                {imgs.map((_, i) => (
                  <button key={i} onClick={e => { e.stopPropagation(); setIdx(i); }}
                    style={{ width: i === idx ? 24 : 8, height: 8, borderRadius: 4, background: i === idx ? ORANGE : "rgba(255,255,255,0.35)", border: "none", cursor: "pointer", transition: "all 0.25s" }} />
                ))}
              </div>
            </>
          )}
        </>
      ) : (
        <div style={{ height: "100%", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 12, color: MUTED }}>
          <Film size={40} style={{ opacity: 0.25 }} />
          <span style={{ fontSize: 12, fontFamily: "monospace", opacity: 0.4 }}>No images added</span>
        </div>
      )}
    </div>
  );
}
function FeaturesRenderer({ s }: { s: Section }) {
  const items = s.featuresItems || [];
  const cols = s.featuresCols || 3;
  return (
    <div>
      {s.featuresTitle && (
        <h2 style={{ fontFamily: s.featuresTitleFont, color: s.featuresTitleColor, fontSize: 32,
          fontWeight: 900, textAlign: "center", marginBottom: 56, letterSpacing: "0.05em", textTransform: "uppercase" }}>
          {s.featuresTitle}
        </h2>
      )}
      <div style={{ display: "grid", gridTemplateColumns: `repeat(${cols}, 1fr)`, gap: 40 }}>
        {items.map((item, i) => (
          <div key={i} style={{ textAlign: "center" }}>
            <div style={{ fontSize: 40, marginBottom: 14 }}>{item.icon}</div>
            <h3 style={{ color: item.color, fontSize: 14, fontWeight: 700, marginBottom: 10, textTransform: "uppercase", letterSpacing: "0.1em" }}>
              {item.title}
            </h3>
            <p style={{ color: "#999", fontSize: 13, lineHeight: 1.65 }}>{item.desc}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
function TwoColRenderer({ s }: { s: Section }) {
  const ratioMap: Record<string, string> = { "1:1": "1fr 1fr", "1:2": "1fr 2fr", "2:1": "2fr 1fr" };
  function Side({ type, text, img, font, size, weight, color, align }: {
    type?: string; text?: string; img?: string;
    font?: string; size?: number; weight?: string; color?: string; align?: string;
  }) {
    if (type === "image") return <img src={img || "https://picsum.photos/600/400"} alt="" style={{ width: "100%", borderRadius: 4 }} />;
    return (
      <p style={{ fontFamily: font, fontSize: size, fontWeight: weight as React.CSSProperties["fontWeight"],
        color: color || "#CCCCCC", textAlign: (align || "left") as React.CSSProperties["textAlign"],
        lineHeight: 1.7, whiteSpace: "pre-wrap" }}>
        {text || "Column text"}
      </p>
    );
  }
  return (
    <div style={{ display: "grid", gridTemplateColumns: ratioMap[s.twoColRatio || "1:1"] || "1fr 1fr", gap: s.twoColGap || 48, alignItems: "center" }}>
      <Side type={s.twoColLeftType} text={s.twoColLeftText} img={s.twoColLeftImg} font={s.twoColLeftFont} size={s.twoColLeftSize} weight={s.twoColLeftWeight} color={s.twoColLeftColor} align={s.twoColLeftAlign} />
      <Side type={s.twoColRightType} text={s.twoColRightText} img={s.twoColRightImg} font={s.twoColRightFont} size={s.twoColRightSize} weight={s.twoColRightWeight} color={s.twoColRightColor} align={s.twoColRightAlign} />
    </div>
  );
}
function DividerRenderer({ s }: { s: Section }) {
  return (
    <div style={{ display: "flex", justifyContent: "center" }}>
      <div style={{ width: `${s.dividerWidth || 80}%`, height: s.dividerThickness || 1, background: s.dividerColor || "#393E46" }} />
    </div>
  );
}
function SpacerRenderer({ s }: { s: Section }) {
  return (
    <div style={{ height: s.spacerHeight || 60, display: "flex", alignItems: "center", justifyContent: "center" }}>
      <div style={{ width: "100%", height: 1, borderTop: "1px dashed rgba(255,255,255,0.06)" }} />
    </div>
  );
}
function CTARenderer({ s }: { s: Section }) {
  return (
    <div style={{ textAlign: (s.ctaAlign || "center") as React.CSSProperties["textAlign"], maxWidth: 600, margin: "0 auto" }}>
      <h2 style={{ fontFamily: s.ctaTitleFont, color: s.ctaTitleColor, fontSize: 38, fontWeight: 900,
        marginBottom: 12, textTransform: "uppercase", letterSpacing: "0.05em" }}>
        {s.ctaTitle || "Get the Game"}
      </h2>
      <p style={{ color: s.ctaSubtitleColor, fontSize: 15, marginBottom: 36, lineHeight: 1.5 }}>{s.ctaSubtitle}</p>
      <div style={{ display: "inline-flex", alignItems: "center", gap: 20, flexWrap: "wrap",
        justifyContent: s.ctaAlign === "center" ? "center" : "flex-start" }}>
        {s.ctaPrice && (
          <span style={{ color: ORANGE, fontSize: 36, fontWeight: 900, fontFamily: "'Cinzel', serif" }}>{s.ctaPrice}</span>
        )}
        <button style={{ background: s.ctaBtnColor, color: s.ctaBtnTextColor, padding: "14px 40px",
          fontSize: 13, fontWeight: 700, letterSpacing: "0.12em", textTransform: "uppercase", border: "none", cursor: "pointer" }}>
          {s.ctaBtnText || "Add to Cart"}
        </button>
      </div>
    </div>
  );
}

// ── Section wrapper with selection chrome ─────────────────────────────────────
function SectionWrapper({ section: s, selected, isFirst, isLast, onSelect, onMoveUp, onMoveDown, onDuplicate, onDelete }: {
  section: Section; selected: boolean; isFirst: boolean; isLast: boolean;
  onSelect: () => void; onMoveUp: () => void; onMoveDown: () => void;
  onDuplicate: () => void; onDelete: () => void;
}) {
  const bgStyle: React.CSSProperties = s.bgImage
    ? { backgroundImage: `url(${s.bgImage})`, backgroundSize: "cover", backgroundPosition: "center" }
    : {};

  return (
    <div onClick={e => { e.stopPropagation(); onSelect(); }}
      style={{ position: "relative", outline: selected ? `2px solid ${ORANGE}` : "2px solid transparent",
        outlineOffset: -2, cursor: "pointer", background: s.bg, ...bgStyle }}>
      {/* bg overlay */}
      {s.bgImage && s.overlay > 0 && (
        <div style={{ position: "absolute", inset: 0, background: s.bg || "#000", opacity: s.overlay / 100, pointerEvents: "none" }} />
      )}
      {/* Spacer dashed background */}
      {s.type === "spacer" && !s.bgImage && (
        <div style={{ position: "absolute", inset: 0, backgroundImage: "repeating-linear-gradient(45deg,rgba(255,255,255,0.02) 0,rgba(255,255,255,0.02) 1px,transparent 0,transparent 50%)", backgroundSize: "8px 8px" }} />
      )}
      {/* Content */}
      <div style={{ position: "relative", paddingTop: s.pt, paddingBottom: s.pb, paddingLeft: s.ph, paddingRight: s.ph, borderRadius: s.radius }}>
        {s.type === "hero" && <HeroRenderer s={s} />}
        {s.type === "text" && <TextRenderer s={s} />}
        {s.type === "image" && <ImageRenderer s={s} />}
        {s.type === "carousel" && <CarouselRenderer s={s} />}
        {s.type === "features" && <FeaturesRenderer s={s} />}
        {s.type === "two-col" && <TwoColRenderer s={s} />}
        {s.type === "divider" && <DividerRenderer s={s} />}
        {s.type === "spacer" && <SpacerRenderer s={s} />}
        {s.type === "cta" && <CTARenderer s={s} />}
      </div>
      {/* Selection label */}
      {selected && (
        <div style={{ position: "absolute", top: 0, left: 0, zIndex: 10, pointerEvents: "none" }}>
          <span className="flex items-center gap-1 text-[8px] font-mono uppercase tracking-wider px-2 py-1"
            style={{ background: ORANGE, color: "#fff" }}>
            {BLOCK_META[s.type]?.label}
          </span>
        </div>
      )}
      {/* Controls toolbar */}
      {selected && (
        <div style={{ position: "absolute", top: 0, right: 0, zIndex: 10 }}>
          <div className="flex items-center" style={{ background: BG, border: `1px solid ${BORDER}` }}>
            <button onClick={e => { e.stopPropagation(); onMoveUp(); }} disabled={isFirst}
              className="flex items-center justify-center w-7 h-7 text-muted-foreground hover:text-foreground disabled:opacity-25 border-r transition-colors"
              style={{ borderColor: BORDER }} title="Move up">
              <ChevronUp size={12} />
            </button>
            <button onClick={e => { e.stopPropagation(); onMoveDown(); }} disabled={isLast}
              className="flex items-center justify-center w-7 h-7 text-muted-foreground hover:text-foreground disabled:opacity-25 border-r transition-colors"
              style={{ borderColor: BORDER }} title="Move down">
              <ChevronDown size={12} />
            </button>
            <button onClick={e => { e.stopPropagation(); onDuplicate(); }}
              className="flex items-center justify-center w-7 h-7 text-muted-foreground hover:text-foreground border-r transition-colors"
              style={{ borderColor: BORDER }} title="Duplicate">
              <Copy size={12} />
            </button>
            <button onClick={e => { e.stopPropagation(); onDelete(); }}
              className="flex items-center justify-center w-7 h-7 text-muted-foreground hover:text-[#e74c3c] transition-colors" title="Delete">
              <Trash2 size={12} />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

// ── Block Palette ──────────────────────────────────────────────────────────────
function BlockPalette({ onAdd }: { onAdd: (type: SectionType) => void }) {
  return (
    <div className="w-52 border-r overflow-y-auto flex flex-col shrink-0" style={{ background: SURFACE, borderColor: BORDER }}>
      <div className="px-4 py-3 border-b shrink-0" style={{ borderColor: BORDER, background: BG }}>
        <p className="text-[7px] font-mono tracking-[0.35em] uppercase" style={{ color: MUTED }}>Add Block</p>
      </div>
      <div className="overflow-y-auto py-2">
        {PALETTE.map(group => (
          <div key={group.group} className="mb-4">
            <p className="px-4 py-1 text-[7px] font-mono tracking-[0.25em] uppercase" style={{ color: `${MUTED}60` }}>{group.group}</p>
            <div className="px-3 space-y-1">
              {group.items.map(item => (
                <button key={item.type} onClick={() => onAdd(item.type)}
                  className="w-full flex items-center gap-3 px-3 py-2.5 border text-left transition-all group"
                  style={{ borderColor: `${BORDER}70`, background: BG }}
                  onMouseEnter={e => { (e.currentTarget).style.borderColor = `${ORANGE}40`; (e.currentTarget).style.background = `${ORANGE}07`; }}
                  onMouseLeave={e => { (e.currentTarget).style.borderColor = `${BORDER}70`; (e.currentTarget).style.background = BG; }}>
                  <div className="w-7 h-7 flex items-center justify-center shrink-0" style={{ background: `${BORDER}50`, border: `1px solid ${BORDER}` }}>
                    <item.Icon size={12} style={{ color: MUTED }} />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-[9px] font-bold" style={{ color: TEXT }}>{item.label}</p>
                    <p className="text-[7px] font-mono truncate" style={{ color: MUTED }}>{item.desc}</p>
                  </div>
                  <Plus size={9} style={{ color: MUTED, opacity: 0.5, flexShrink: 0 }} />
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Properties Panel ──────────────────────────────────────────────────────────
function PropertiesPanel({ section, onChange }: {
  section: Section | null;
  onChange: (id: string, updates: Partial<Section>) => void;
}) {
  const [twoColSide, setTwoColSide] = useState<"left" | "right">("left");

  if (!section) {
    return (
      <div className="w-72 border-l flex flex-col shrink-0" style={{ background: SURFACE, borderColor: BORDER }}>
        <div className="px-4 py-3 border-b shrink-0" style={{ borderColor: BORDER, background: BG }}>
          <p className="text-[7px] font-mono tracking-[0.35em] uppercase" style={{ color: MUTED }}>Properties</p>
        </div>
        <div className="flex-1 flex flex-col items-center justify-center text-center p-8 gap-3">
          <Settings size={28} style={{ color: MUTED, opacity: 0.2 }} />
          <p className="text-[10px] font-bold" style={{ color: MUTED }}>No block selected</p>
          <p className="text-[8px] font-mono" style={{ color: `${MUTED}50` }}>Click any block on the canvas to edit its properties</p>
        </div>
      </div>
    );
  }

  const u = (updates: Partial<Section>) => onChange(section.id, updates);
  const s = section;
  const { Icon } = BLOCK_META[s.type] || { Icon: Settings };

  return (
    <div className="w-72 border-l flex flex-col shrink-0" style={{ background: SURFACE, borderColor: BORDER }}>
      {/* Panel header */}
      <div className="px-4 py-3 border-b flex items-center gap-2.5 shrink-0" style={{ borderColor: BORDER, background: BG }}>
        <div className="w-6 h-6 flex items-center justify-center shrink-0" style={{ background: `${ORANGE}15`, border: `1px solid ${ORANGE}30` }}>
          <Icon size={12} style={{ color: ORANGE }} />
        </div>
        <span className="text-[10px] font-black uppercase tracking-wider" style={{ fontFamily: "'Cinzel', serif", color: TEXT }}>
          {BLOCK_META[s.type]?.label}
        </span>
      </div>

      <div className="flex-1 overflow-y-auto">

        {/* ── Background (all types) ── */}
        <PropSection title="Background">
          <PropRow label="Color">
            <ColorField value={s.bg} onChange={v => u({ bg: v })} />
          </PropRow>
          <PropRow label="Image URL">
            <TxtInput value={s.bgImage} onChange={v => u({ bgImage: v })} placeholder="https://…" />
          </PropRow>
          {s.bgImage && <SliderField value={s.overlay} onChange={v => u({ overlay: v })} label="Overlay Opacity" />}
        </PropSection>

        {/* ── Spacing (all types) ── */}
        <PropSection title="Spacing">
          <div className="grid grid-cols-2 gap-2">
            <PropRow label="Pad Top"><NumField value={s.pt} onChange={v => u({ pt: v })} unit="px" max={400} /></PropRow>
            <PropRow label="Pad Bottom"><NumField value={s.pb} onChange={v => u({ pb: v })} unit="px" max={400} /></PropRow>
          </div>
          <PropRow label="Pad Horizontal"><NumField value={s.ph} onChange={v => u({ ph: v })} unit="px" max={300} /></PropRow>
          <PropRow label="Border Radius"><NumField value={s.radius} onChange={v => u({ radius: v })} unit="px" max={80} /></PropRow>
        </PropSection>

        {/* ── HERO content ── */}
        {s.type === "hero" && <>
          <PropSection title="Content">
            <PropRow label="Title"><TxtArea value={s.heroTitle || ""} onChange={v => u({ heroTitle: v })} rows={2} /></PropRow>
            <PropRow label="Subtitle"><TxtArea value={s.heroSubtitle || ""} onChange={v => u({ heroSubtitle: v })} rows={3} /></PropRow>
            <PropRow label="Button Text"><TxtInput value={s.heroCtaText || ""} onChange={v => u({ heroCtaText: v })} /></PropRow>
            <PropRow label="Button Background"><ColorField value={s.heroCtaBg || "#FD7014"} onChange={v => u({ heroCtaBg: v })} /></PropRow>
            <PropRow label="Button Text Color"><ColorField value={s.heroCtaColor || "#ffffff"} onChange={v => u({ heroCtaColor: v })} /></PropRow>
          </PropSection>
          <PropSection title="Typography">
            <PropRow label="Title Font"><SelField value={s.heroTitleFont || "'Cinzel', serif"} onChange={v => u({ heroTitleFont: v })} options={FONTS} /></PropRow>
            <div className="grid grid-cols-2 gap-2">
              <PropRow label="Size"><NumField value={s.heroTitleSize || 56} onChange={v => u({ heroTitleSize: v })} unit="px" min={12} max={120} /></PropRow>
              <PropRow label="Weight"><SelField value={s.heroTitleWeight || "900"} onChange={v => u({ heroTitleWeight: v })} options={WEIGHTS} /></PropRow>
            </div>
            <PropRow label="Title Color"><ColorField value={s.heroTitleColor || "#ffffff"} onChange={v => u({ heroTitleColor: v })} /></PropRow>
            <PropRow label="Subtitle Color"><ColorField value={s.heroSubtitleColor || "#cccccc"} onChange={v => u({ heroSubtitleColor: v })} /></PropRow>
            <PropRow label="Alignment"><AlignField value={s.heroAlign || "center"} onChange={v => u({ heroAlign: v })} /></PropRow>
          </PropSection>
        </>}

        {/* ── TEXT content ── */}
        {s.type === "text" && <>
          <PropSection title="Content">
            <PropRow label="Text"><TxtArea value={s.textContent || ""} onChange={v => u({ textContent: v })} rows={6} /></PropRow>
            <PropRow label="Max Width"><NumField value={s.textMaxWidth || 700} onChange={v => u({ textMaxWidth: v })} unit="px" min={200} max={1400} step={20} /></PropRow>
          </PropSection>
          <PropSection title="Typography">
            <PropRow label="Font Family"><SelField value={s.textFont || "'Raleway', sans-serif"} onChange={v => u({ textFont: v })} options={FONTS} /></PropRow>
            <div className="grid grid-cols-2 gap-2">
              <PropRow label="Size"><NumField value={s.textSize || 16} onChange={v => u({ textSize: v })} unit="px" min={10} max={72} /></PropRow>
              <PropRow label="Weight"><SelField value={s.textWeight || "400"} onChange={v => u({ textWeight: v })} options={WEIGHTS} /></PropRow>
            </div>
            <PropRow label="Color"><ColorField value={s.textColor || "#CCCCCC"} onChange={v => u({ textColor: v })} /></PropRow>
            <div className="grid grid-cols-2 gap-2">
              <PropRow label="Align"><AlignField value={s.textAlign || "left"} onChange={v => u({ textAlign: v })} /></PropRow>
              <PropRow label="Line Height"><NumField value={s.textLineHeight || 1.8} onChange={v => u({ textLineHeight: v })} min={1} max={3} step={0.1} /></PropRow>
            </div>
          </PropSection>
        </>}

        {/* ── IMAGE content ── */}
        {s.type === "image" && (
          <PropSection title="Content">
            <PropRow label="Image URL"><TxtInput value={s.imageSrc || ""} onChange={v => u({ imageSrc: v })} placeholder="https://…" /></PropRow>
            <PropRow label="Alt Text"><TxtInput value={s.imageAlt || ""} onChange={v => u({ imageAlt: v })} placeholder="Screenshot description" /></PropRow>
            <div className="grid grid-cols-2 gap-2">
              <PropRow label="Max Width (%)"><NumField value={s.imageMaxWidth ?? 100} onChange={v => u({ imageMaxWidth: v })} unit="%" min={10} max={100} /></PropRow>
              <PropRow label="Border Radius"><NumField value={s.imageRadius || 0} onChange={v => u({ imageRadius: v })} unit="px" max={60} /></PropRow>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-[8px] font-mono" style={{ color: MUTED }}>Drop Shadow</span>
              <button onClick={() => u({ imageShadow: !s.imageShadow })}
                className="flex items-center gap-1.5 px-2.5 py-1 border text-[8px] font-mono transition-all"
                style={{ borderColor: s.imageShadow ? `${ORANGE}50` : BORDER, color: s.imageShadow ? ORANGE : MUTED, background: s.imageShadow ? `${ORANGE}12` : "transparent" }}>
                {s.imageShadow && <Check size={9} />}{s.imageShadow ? "On" : "Off"}
              </button>
            </div>
          </PropSection>
        )}

        {/* ── CAROUSEL content ── */}
        {s.type === "carousel" && (
          <PropSection title="Content">
            <div className="grid grid-cols-2 gap-2">
              <PropRow label="Height"><NumField value={s.carouselHeight || 420} onChange={v => u({ carouselHeight: v })} unit="px" min={200} max={800} step={10} /></PropRow>
              <PropRow label="Radius"><NumField value={s.carouselRadius || 0} onChange={v => u({ carouselRadius: v })} unit="px" max={40} /></PropRow>
            </div>
            <div className="space-y-2 mt-1">
              <p className="text-[8px] font-mono" style={{ color: MUTED }}>Images — {(s.carouselImages || []).length}</p>
              {(s.carouselImages || []).map((img, i) => (
                <div key={i} className="flex items-center gap-1.5">
                  <div className="w-9 h-6 shrink-0 border overflow-hidden" style={{ borderColor: BORDER }}>
                    <img src={img} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                  </div>
                  <input value={img} onChange={e => {
                    const imgs = [...(s.carouselImages || [])]; imgs[i] = e.target.value;
                    u({ carouselImages: imgs });
                  }} className="flex-1 border px-2 py-1 text-[8px] font-mono outline-none"
                    style={{ borderColor: BORDER, background: BG, color: TEXT }} placeholder="Image URL" />
                  <button onClick={() => u({ carouselImages: (s.carouselImages || []).filter((_, j) => j !== i) })}
                    className="w-5 h-5 flex items-center justify-center border text-muted-foreground hover:text-[#e74c3c] transition-colors shrink-0"
                    style={{ borderColor: BORDER }}>
                    <X size={8} />
                  </button>
                </div>
              ))}
              <button onClick={() => u({ carouselImages: [...(s.carouselImages || []), `https://picsum.photos/seed/${uid()}/900/450`] })}
                className="w-full flex items-center justify-center gap-1.5 border py-1.5 text-[8px] font-mono transition-colors"
                style={{ borderColor: `${BORDER}80`, color: MUTED, borderStyle: "dashed" }}>
                <Plus size={9} /> Add Image
              </button>
            </div>
          </PropSection>
        )}

        {/* ── FEATURES content ── */}
        {s.type === "features" && (
          <PropSection title="Content">
            <PropRow label="Section Title"><TxtInput value={s.featuresTitle || ""} onChange={v => u({ featuresTitle: v })} placeholder="Key Features" /></PropRow>
            <PropRow label="Title Font"><SelField value={s.featuresTitleFont || "'Cinzel', serif"} onChange={v => u({ featuresTitleFont: v })} options={FONTS} /></PropRow>
            <PropRow label="Title Color"><ColorField value={s.featuresTitleColor || "#ffffff"} onChange={v => u({ featuresTitleColor: v })} /></PropRow>
            <PropRow label="Columns">
              <div className="flex border" style={{ borderColor: BORDER }}>
                {[2, 3, 4].map(n => (
                  <button key={n} onClick={() => u({ featuresCols: n })}
                    className="flex-1 py-1.5 text-[9px] font-mono transition-colors"
                    style={{ background: (s.featuresCols || 3) === n ? `${ORANGE}20` : "transparent", color: (s.featuresCols || 3) === n ? ORANGE : MUTED, borderRight: n < 4 ? `1px solid ${BORDER}` : undefined }}>
                    {n}
                  </button>
                ))}
              </div>
            </PropRow>
            <div className="space-y-3 mt-1">
              {(s.featuresItems || []).map((item, i) => (
                <div key={i} className="border p-2.5 space-y-2" style={{ borderColor: BORDER, background: `${BG}80` }}>
                  <div className="flex items-center justify-between">
                    <span className="text-[7px] font-mono uppercase tracking-widest" style={{ color: MUTED }}>Feature {i + 1}</span>
                    <button onClick={() => u({ featuresItems: (s.featuresItems || []).filter((_, j) => j !== i) })}
                      className="w-4 h-4 flex items-center justify-center text-muted-foreground hover:text-[#e74c3c] transition-colors">
                      <X size={8} />
                    </button>
                  </div>
                  <div className="flex gap-2">
                    <input value={item.icon} onChange={e => {
                      const items = [...(s.featuresItems || [])]; items[i] = { ...items[i], icon: e.target.value };
                      u({ featuresItems: items });
                    }} className="w-10 border text-center text-sm bg-transparent outline-none py-1"
                      style={{ borderColor: BORDER, background: BG, color: TEXT }} placeholder="🎮" />
                    <input value={item.title} onChange={e => {
                      const items = [...(s.featuresItems || [])]; items[i] = { ...items[i], title: e.target.value };
                      u({ featuresItems: items });
                    }} className="flex-1 border px-2 py-1 text-[9px] font-mono bg-transparent outline-none"
                      style={{ borderColor: BORDER, background: BG, color: TEXT }} placeholder="Feature title" />
                  </div>
                  <textarea value={item.desc} onChange={e => {
                    const items = [...(s.featuresItems || [])]; items[i] = { ...items[i], desc: e.target.value };
                    u({ featuresItems: items });
                  }} rows={2} className="w-full border px-2 py-1 text-[9px] font-mono bg-transparent outline-none resize-none"
                    style={{ borderColor: BORDER, background: BG, color: TEXT }} placeholder="Description" />
                  <div className="flex items-center gap-2">
                    <span className="text-[7px] font-mono" style={{ color: MUTED }}>Accent Color</span>
                    <div className="flex items-center gap-1.5 flex-1 border px-1.5 py-1" style={{ borderColor: BORDER, background: BG }}>
                      <div className="w-3.5 h-3.5 shrink-0 border" style={{ background: item.color, borderColor: `${BORDER}80` }} />
                      <input value={item.color} onChange={e => {
                        const items = [...(s.featuresItems || [])]; items[i] = { ...items[i], color: e.target.value };
                        u({ featuresItems: items });
                      }} className="flex-1 bg-transparent text-[8px] font-mono outline-none" style={{ color: TEXT }} />
                    </div>
                  </div>
                </div>
              ))}
              <button onClick={() => u({ featuresItems: [...(s.featuresItems || []), { icon: "⭐", title: "New Feature", desc: "Describe this feature.", color: ORANGE }] })}
                className="w-full flex items-center justify-center gap-1.5 border py-1.5 text-[8px] font-mono transition-colors"
                style={{ borderColor: `${BORDER}80`, color: MUTED, borderStyle: "dashed" }}>
                <Plus size={9} /> Add Feature
              </button>
            </div>
          </PropSection>
        )}

        {/* ── TWO-COL layout + content ── */}
        {s.type === "two-col" && <>
          <PropSection title="Layout">
            <PropRow label="Column Ratio">
              <SelField value={s.twoColRatio || "1:1"} onChange={v => u({ twoColRatio: v })}
                options={[{ label: "Equal (1:1)", value: "1:1" }, { label: "Left heavy (2:1)", value: "2:1" }, { label: "Right heavy (1:2)", value: "1:2" }]} />
            </PropRow>
            <PropRow label="Gap Between Columns"><NumField value={s.twoColGap || 48} onChange={v => u({ twoColGap: v })} unit="px" min={0} max={120} /></PropRow>
          </PropSection>
          <PropSection title="Column Content">
            <div className="flex border mb-3" style={{ borderColor: BORDER }}>
              {(["left", "right"] as const).map(side => (
                <button key={side} onClick={() => setTwoColSide(side)}
                  className="flex-1 py-1.5 text-[8px] font-mono uppercase tracking-wider transition-colors"
                  style={{ background: twoColSide === side ? `${ORANGE}15` : "transparent", color: twoColSide === side ? ORANGE : MUTED, borderRight: side === "left" ? `1px solid ${BORDER}` : undefined }}>
                  {side === "left" ? "← Left" : "Right →"}
                </button>
              ))}
            </div>
            {twoColSide === "left" ? (
              <div className="space-y-2">
                <PropRow label="Type">
                  <SelField value={s.twoColLeftType || "text"} onChange={v => u({ twoColLeftType: v as "text" | "image" })} options={[{ label: "Text", value: "text" }, { label: "Image", value: "image" }]} />
                </PropRow>
                {(s.twoColLeftType || "text") === "text" ? <>
                  <PropRow label="Content"><TxtArea value={s.twoColLeftText || ""} onChange={v => u({ twoColLeftText: v })} rows={5} /></PropRow>
                  <PropRow label="Font"><SelField value={s.twoColLeftFont || "'Raleway', sans-serif"} onChange={v => u({ twoColLeftFont: v })} options={FONTS} /></PropRow>
                  <div className="grid grid-cols-2 gap-2">
                    <PropRow label="Size"><NumField value={s.twoColLeftSize || 14} onChange={v => u({ twoColLeftSize: v })} unit="px" min={10} max={48} /></PropRow>
                    <PropRow label="Weight"><SelField value={s.twoColLeftWeight || "400"} onChange={v => u({ twoColLeftWeight: v })} options={WEIGHTS} /></PropRow>
                  </div>
                  <PropRow label="Color"><ColorField value={s.twoColLeftColor || "#CCCCCC"} onChange={v => u({ twoColLeftColor: v })} /></PropRow>
                  <PropRow label="Alignment"><AlignField value={s.twoColLeftAlign || "left"} onChange={v => u({ twoColLeftAlign: v })} /></PropRow>
                </> : (
                  <PropRow label="Image URL"><TxtInput value={s.twoColLeftImg || ""} onChange={v => u({ twoColLeftImg: v })} placeholder="https://…" /></PropRow>
                )}
              </div>
            ) : (
              <div className="space-y-2">
                <PropRow label="Type">
                  <SelField value={s.twoColRightType || "image"} onChange={v => u({ twoColRightType: v as "text" | "image" })} options={[{ label: "Text", value: "text" }, { label: "Image", value: "image" }]} />
                </PropRow>
                {(s.twoColRightType || "image") === "text" ? <>
                  <PropRow label="Content"><TxtArea value={s.twoColRightText || ""} onChange={v => u({ twoColRightText: v })} rows={5} /></PropRow>
                  <PropRow label="Font"><SelField value={s.twoColRightFont || "'Raleway', sans-serif"} onChange={v => u({ twoColRightFont: v })} options={FONTS} /></PropRow>
                  <div className="grid grid-cols-2 gap-2">
                    <PropRow label="Size"><NumField value={s.twoColRightSize || 14} onChange={v => u({ twoColRightSize: v })} unit="px" min={10} max={48} /></PropRow>
                    <PropRow label="Weight"><SelField value={s.twoColRightWeight || "400"} onChange={v => u({ twoColRightWeight: v })} options={WEIGHTS} /></PropRow>
                  </div>
                  <PropRow label="Color"><ColorField value={s.twoColRightColor || "#CCCCCC"} onChange={v => u({ twoColRightColor: v })} /></PropRow>
                  <PropRow label="Alignment"><AlignField value={s.twoColRightAlign || "left"} onChange={v => u({ twoColRightAlign: v })} /></PropRow>
                </> : (
                  <PropRow label="Image URL"><TxtInput value={s.twoColRightImg || ""} onChange={v => u({ twoColRightImg: v })} placeholder="https://…" /></PropRow>
                )}
              </div>
            )}
          </PropSection>
        </>}

        {/* ── DIVIDER ── */}
        {s.type === "divider" && (
          <PropSection title="Divider Style">
            <PropRow label="Color"><ColorField value={s.dividerColor || "#393E46"} onChange={v => u({ dividerColor: v })} /></PropRow>
            <div className="grid grid-cols-2 gap-2">
              <PropRow label="Thickness"><NumField value={s.dividerThickness || 1} onChange={v => u({ dividerThickness: v })} unit="px" min={1} max={12} /></PropRow>
              <PropRow label="Width"><NumField value={s.dividerWidth || 80} onChange={v => u({ dividerWidth: v })} unit="%" min={10} max={100} /></PropRow>
            </div>
          </PropSection>
        )}

        {/* ── SPACER ── */}
        {s.type === "spacer" && (
          <PropSection title="Spacer">
            <PropRow label="Height"><NumField value={s.spacerHeight || 60} onChange={v => u({ spacerHeight: v })} unit="px" min={8} max={400} step={8} /></PropRow>
          </PropSection>
        )}

        {/* ── CTA content ── */}
        {s.type === "cta" && <>
          <PropSection title="Content">
            <PropRow label="Title"><TxtArea value={s.ctaTitle || ""} onChange={v => u({ ctaTitle: v })} rows={2} /></PropRow>
            <PropRow label="Subtitle"><TxtArea value={s.ctaSubtitle || ""} onChange={v => u({ ctaSubtitle: v })} rows={2} /></PropRow>
            <PropRow label="Price"><TxtInput value={s.ctaPrice || ""} onChange={v => u({ ctaPrice: v })} placeholder="$29.99" /></PropRow>
            <PropRow label="Button Text"><TxtInput value={s.ctaBtnText || ""} onChange={v => u({ ctaBtnText: v })} /></PropRow>
            <PropRow label="Button Color"><ColorField value={s.ctaBtnColor || "#FD7014"} onChange={v => u({ ctaBtnColor: v })} /></PropRow>
            <PropRow label="Button Text Color"><ColorField value={s.ctaBtnTextColor || "#ffffff"} onChange={v => u({ ctaBtnTextColor: v })} /></PropRow>
          </PropSection>
          <PropSection title="Typography">
            <PropRow label="Title Font"><SelField value={s.ctaTitleFont || "'Cinzel', serif"} onChange={v => u({ ctaTitleFont: v })} options={FONTS} /></PropRow>
            <PropRow label="Title Color"><ColorField value={s.ctaTitleColor || "#ffffff"} onChange={v => u({ ctaTitleColor: v })} /></PropRow>
            <PropRow label="Subtitle Color"><ColorField value={s.ctaSubtitleColor || "#AAAAAA"} onChange={v => u({ ctaSubtitleColor: v })} /></PropRow>
            <PropRow label="Alignment"><AlignField value={s.ctaAlign || "center"} onChange={v => u({ ctaAlign: v })} /></PropRow>
          </PropSection>
        </>}

      </div>
    </div>
  );
}

// ── Main App ──────────────────────────────────────────────────────────────────
export default function App() {
  const [state, setState] = useState({ sections: INITIAL, history: [INITIAL], historyIdx: 0 });
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [device, setDevice] = useState<Device>("desktop");
  const [gameTitle, setGameTitle] = useState("Elden Throne");
  const [toast, setToast] = useState<string | null>(null);

  const { sections, history, historyIdx } = state;

  function showToast(msg: string) { setToast(msg); setTimeout(() => setToast(null), 2200); }

  function mutateSections(newSections: Section[]) {
    setState(prev => ({
      sections: newSections,
      history: [...prev.history.slice(0, prev.historyIdx + 1), newSections],
      historyIdx: prev.historyIdx + 1,
    }));
  }
  function undo() {
    setState(prev => {
      if (prev.historyIdx <= 0) return prev;
      const idx = prev.historyIdx - 1;
      return { sections: prev.history[idx], history: prev.history, historyIdx: idx };
    });
  }
  function redo() {
    setState(prev => {
      if (prev.historyIdx >= prev.history.length - 1) return prev;
      const idx = prev.historyIdx + 1;
      return { sections: prev.history[idx], history: prev.history, historyIdx: idx };
    });
  }
  function addSection(type: SectionType) {
    const s = createSection(type);
    mutateSections([...sections, s]);
    setSelectedId(s.id);
    showToast(`Added: ${BLOCK_META[type]?.label}`);
  }
  function updateSection(id: string, updates: Partial<Section>) {
    mutateSections(sections.map(s => s.id === id ? { ...s, ...updates } : s));
  }
  function moveUp(i: number) {
    if (i <= 0) return;
    const arr = [...sections]; [arr[i - 1], arr[i]] = [arr[i], arr[i - 1]];
    mutateSections(arr);
  }
  function moveDown(i: number) {
    if (i >= sections.length - 1) return;
    const arr = [...sections]; [arr[i], arr[i + 1]] = [arr[i + 1], arr[i]];
    mutateSections(arr);
  }
  function duplicateSection(i: number) {
    const duped = { ...sections[i], id: uid() };
    const arr = [...sections]; arr.splice(i + 1, 0, duped);
    mutateSections(arr);
    setSelectedId(duped.id);
    showToast("Block duplicated");
  }
  function deleteSection(i: number) {
    mutateSections(sections.filter((_, j) => j !== i));
    setSelectedId(null);
  }

  const selectedSection = sections.find(s => s.id === selectedId) ?? null;
  const deviceMax = device === "mobile" ? 375 : device === "tablet" ? 768 : undefined;

  return (
    <div className="h-screen flex flex-col overflow-hidden" style={{ background: BG, color: TEXT }}>

      {/* Toast */}
      {toast && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2 px-4 py-2.5 border shadow-2xl text-[9px] font-mono tracking-wider"
          style={{ background: SURFACE, borderColor: `${ORANGE}30`, color: TEXT, zIndex: 100 }}>
          <Check size={10} style={{ color: "#4caf80" }} />{toast}
        </div>
      )}

      {/* ── Top toolbar ── */}
      <div className="flex items-center gap-3 px-4 border-b shrink-0" style={{ background: SURFACE, borderColor: BORDER, height: 48 }}>
        <img src={hathorLogo} alt="Hathor" className="h-5 shrink-0" />
        <div className="w-px h-5" style={{ background: BORDER }} />
        <span className="text-[7px] font-mono tracking-[0.3em] uppercase shrink-0" style={{ color: `${MUTED}80` }}>Page Designer</span>
        <div className="w-px h-5" style={{ background: BORDER }} />
        <input
          value={gameTitle} onChange={e => setGameTitle(e.target.value)}
          className="bg-transparent text-[11px] font-black outline-none border-b border-transparent transition-colors"
          style={{ fontFamily: "'Cinzel', serif", color: TEXT, minWidth: 140 }}
          onFocus={e => (e.currentTarget.style.borderBottomColor = ORANGE)}
          onBlur={e => (e.currentTarget.style.borderBottomColor = "transparent")}
        />
        <div className="flex-1" />

        {/* Device preview toggle */}
        <div className="flex border" style={{ borderColor: BORDER }}>
          {(["desktop", "tablet", "mobile"] as Device[]).map(d => {
            const Icon = d === "desktop" ? Monitor : d === "tablet" ? Tablet : Smartphone;
            return (
              <button key={d} onClick={() => setDevice(d)}
                className="flex items-center justify-center w-8 h-8 transition-colors"
                title={d.charAt(0).toUpperCase() + d.slice(1)}
                style={{ background: device === d ? `${ORANGE}20` : "transparent", color: device === d ? ORANGE : MUTED, borderRight: d !== "mobile" ? `1px solid ${BORDER}` : undefined }}>
                <Icon size={13} />
              </button>
            );
          })}
        </div>

        <div className="w-px h-5" style={{ background: BORDER }} />

        {/* Undo / Redo */}
        <button onClick={undo} disabled={historyIdx <= 0}
          className="w-7 h-7 flex items-center justify-center text-muted-foreground hover:text-foreground disabled:opacity-25 transition-colors"
          title="Undo">
          <RotateCcw size={13} />
        </button>
        <button onClick={redo} disabled={historyIdx >= history.length - 1}
          className="w-7 h-7 flex items-center justify-center text-muted-foreground hover:text-foreground disabled:opacity-25 transition-colors"
          title="Redo">
          <RotateCw size={13} />
        </button>

        <div className="w-px h-5" style={{ background: BORDER }} />

        {/* Actions */}
        <button onClick={() => showToast("Draft saved")}
          className="flex items-center gap-1.5 px-3 h-8 border text-[8px] font-black uppercase tracking-wider transition-all"
          style={{ borderColor: BORDER, color: MUTED }}
          onMouseEnter={e => (e.currentTarget.style.color = TEXT)}
          onMouseLeave={e => (e.currentTarget.style.color = MUTED)}>
          <Save size={11} /> Save Draft
        </button>
        <button onClick={() => showToast("Page published!")}
          className="flex items-center gap-1.5 px-3 h-8 text-[8px] font-black uppercase tracking-wider transition-opacity hover:opacity-90"
          style={{ background: ORANGE, color: "#fff" }}>
          <Upload size={11} /> Publish
        </button>
      </div>

      {/* ── Body ── */}
      <div className="flex flex-1 overflow-hidden">

        {/* Left — block palette */}
        <BlockPalette onAdd={addSection} />

        {/* Center — canvas */}
        <div className="flex-1 overflow-y-auto" style={{ background: "#13131a" }}
          onClick={() => setSelectedId(null)}>
          {/* Device label bar */}
          <div className="flex items-center justify-center py-1.5 border-b" style={{ borderColor: `${BORDER}30` }}>
            <span className="text-[7px] font-mono tracking-widest uppercase" style={{ color: `${MUTED}45` }}>
              {device === "desktop" ? "Desktop" : device === "tablet" ? "Tablet — 768px" : "Mobile — 375px"}
            </span>
          </div>

          {/* Page frame */}
          <div style={{ maxWidth: deviceMax, margin: "0 auto", minHeight: "calc(100vh - 72px)",
              boxShadow: deviceMax ? "0 0 0 1px rgba(255,255,255,0.04), 0 20px 80px rgba(0,0,0,0.7)" : "none" }}
            onClick={e => e.stopPropagation()}>
            {sections.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full" style={{ minHeight: 480, gap: 12 }}>
                <Layers size={40} style={{ color: MUTED, opacity: 0.15 }} />
                <p className="text-[13px] font-bold" style={{ color: MUTED, opacity: 0.4 }}>Your page is empty</p>
                <p className="text-[9px] font-mono" style={{ color: MUTED, opacity: 0.25 }}>Click a block in the left panel to add it to your page</p>
              </div>
            ) : sections.map((s, i) => (
              <SectionWrapper
                key={s.id} section={s}
                selected={s.id === selectedId}
                isFirst={i === 0} isLast={i === sections.length - 1}
                onSelect={() => setSelectedId(s.id)}
                onMoveUp={() => moveUp(i)}
                onMoveDown={() => moveDown(i)}
                onDuplicate={() => duplicateSection(i)}
                onDelete={() => deleteSection(i)}
              />
            ))}
          </div>
        </div>

        {/* Right — properties */}
        <PropertiesPanel section={selectedSection} onChange={updateSection} />
      </div>
    </div>
  );
}
