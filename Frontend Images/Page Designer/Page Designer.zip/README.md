
  # Temp Categories

  This is a code bundle for Temp Categories. The original project is available at https://www.figma.com/design/q8I8gjX9cUkvQbothfxXOL/Temp-Categories.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  